package edu.gatech.cs6310;

public class Item {
    public String name;
    public Integer weight;

    public Item(String name, Integer weight) {
        this.name = name;
        this.weight = weight;
    }
}
